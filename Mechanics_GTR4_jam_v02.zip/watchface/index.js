﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_tr_text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 311,
              src: 'dnd_vector_white.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 379,
              y: 311,
              src: 'bt_vector_grey2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 379,
              y: 116,
              src: 'clock_tr.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 44,
              image_array: ["moon_tr_01.png","moon_tr_02.png","moon_tr_03.png","moon_tr_04.png","moon_tr_05.png","moon_tr_06.png","moon_tr_07.png","moon_tr_08.png","moon_tr_09.png","moon_tr_10.png","moon_tr_11.png","moon_tr_12.png","moon_tr_13.png","moon_tr_14.png","moon_tr_15.png","moon_tr_16.png","moon_tr_17.png","moon_tr_18.png","moon_tr_19.png","moon_tr_20.png","moon_tr_21.png","moon_tr_22.png","moon_tr_23.png","moon_tr_24.png","moon_tr_25.png","moon_tr_26.png","moon_tr_27.png","moon_tr_28.png","moon_tr_29.png","moon_tr_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 308,
              font_array: ["data13_tr_0.png","data13_tr_1.png","data13_tr_2.png","data13_tr_3.png","data13_tr_4.png","data13_tr_5.png","data13_tr_6.png","data13_tr_7.png","data13_tr_8.png","data13_tr_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'data13_tr_minus.png',
              invalid_image: 'data13_tr_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 117,
              image_array: ["weather_tr_01.png","weather_tr_02.png","weather_tr_03.png","weather_tr_04.png","weather_tr_05.png","weather_tr_06.png","weather_tr_07.png","weather_tr_08.png","weather_tr_09.png","weather_tr_10.png","weather_tr_11.png","weather_tr_12.png","weather_tr_13.png","weather_tr_14.png","weather_tr_15.png","weather_tr_16.png","weather_tr_17.png","weather_tr_18.png","weather_tr_19.png","weather_tr_20.png","weather_tr_21.png","weather_tr_22.png","weather_tr_23.png","weather_tr_24.png","weather_tr_25.png","weather_tr_26.png","weather_tr_27.png","weather_tr_28.png","weather_tr_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 291,
              font_array: ["data13_tr_0.png","data13_tr_1.png","data13_tr_2.png","data13_tr_3.png","data13_tr_4.png","data13_tr_5.png","data13_tr_6.png","data13_tr_7.png","data13_tr_8.png","data13_tr_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'data13_tr_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 380,
              font_array: ["alt_tr_0.png","alt_tr_1.png","alt_tr_2.png","alt_tr_3.png","alt_tr_4.png","alt_tr_5.png","alt_tr_6.png","alt_tr_7.png","alt_tr_8.png","alt_tr_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 308,
              font_array: ["data13_tr_0.png","data13_tr_1.png","data13_tr_2.png","data13_tr_3.png","data13_tr_4.png","data13_tr_5.png","data13_tr_6.png","data13_tr_7.png","data13_tr_8.png","data13_tr_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'data13_tr_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point_tr.png',
              center_x: 95,
              center_y: 234,
              x: 16,
              y: 74,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 222,
              font_array: ["data17_tr_0.png","data17_tr_1.png","data17_tr_2.png","data17_tr_3.png","data17_tr_4.png","data17_tr_5.png","data17_tr_6.png","data17_tr_7.png","data17_tr_8.png","data17_tr_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 319,
              y: 179,
              week_en: ["week_vector_1.png","week_vector_2.png","week_vector_3.png","week_vector_4.png","week_vector_5.png","week_vector_6.png","week_vector_7.png"],
              week_tc: ["week_vector_1.png","week_vector_2.png","week_vector_3.png","week_vector_4.png","week_vector_5.png","week_vector_6.png","week_vector_7.png"],
              week_sc: ["week_vector_1.png","week_vector_2.png","week_vector_3.png","week_vector_4.png","week_vector_5.png","week_vector_6.png","week_vector_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 352,
              year_startY: 240,
              year_sc_array: ["year_tr_0.png","year_tr_1.png","year_tr_2.png","year_tr_3.png","year_tr_4.png","year_tr_5.png","year_tr_6.png","year_tr_7.png","year_tr_8.png","year_tr_9.png"],
              year_tc_array: ["year_tr_0.png","year_tr_1.png","year_tr_2.png","year_tr_3.png","year_tr_4.png","year_tr_5.png","year_tr_6.png","year_tr_7.png","year_tr_8.png","year_tr_9.png"],
              year_en_array: ["year_tr_0.png","year_tr_1.png","year_tr_2.png","year_tr_3.png","year_tr_4.png","year_tr_5.png","year_tr_6.png","year_tr_7.png","year_tr_8.png","year_tr_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 337,
              month_startY: 207,
              month_sc_array: ["month_tr_01.png","month_tr_02.png","month_tr_03.png","month_tr_04.png","month_tr_05.png","month_tr_06.png","month_tr_07.png","month_tr_08.png","month_tr_09.png","month_tr_10.png","month_tr_11.png","month_tr_12.png"],
              month_tc_array: ["month_tr_01.png","month_tr_02.png","month_tr_03.png","month_tr_04.png","month_tr_05.png","month_tr_06.png","month_tr_07.png","month_tr_08.png","month_tr_09.png","month_tr_10.png","month_tr_11.png","month_tr_12.png"],
              month_en_array: ["month_tr_01.png","month_tr_02.png","month_tr_03.png","month_tr_04.png","month_tr_05.png","month_tr_06.png","month_tr_07.png","month_tr_08.png","month_tr_09.png","month_tr_10.png","month_tr_11.png","month_tr_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 291,
              day_startY: 216,
              day_sc_array: ["day_tr_0.png","day_tr_1.png","day_tr_2.png","day_tr_3.png","day_tr_4.png","day_tr_5.png","day_tr_6.png","day_tr_7.png","day_tr_8.png","day_tr_9.png"],
              day_tc_array: ["day_tr_0.png","day_tr_1.png","day_tr_2.png","day_tr_3.png","day_tr_4.png","day_tr_5.png","day_tr_6.png","day_tr_7.png","day_tr_8.png","day_tr_9.png"],
              day_en_array: ["day_tr_0.png","day_tr_1.png","day_tr_2.png","day_tr_3.png","day_tr_4.png","day_tr_5.png","day_tr_6.png","day_tr_7.png","day_tr_8.png","day_tr_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 161,
              hour_startY: 105,
              hour_array: ["time_tr_0.png","time_tr_1.png","time_tr_2.png","time_tr_3.png","time_tr_4.png","time_tr_5.png","time_tr_6.png","time_tr_7.png","time_tr_8.png","time_tr_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time_tr_dot.png',
              hour_unit_tc: 'time_tr_dot.png',
              hour_unit_en: 'time_tr_dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time_tr_0.png","time_tr_1.png","time_tr_2.png","time_tr_3.png","time_tr_4.png","time_tr_5.png","time_tr_6.png","time_tr_7.png","time_tr_8.png","time_tr_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 38,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 38,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 38,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}